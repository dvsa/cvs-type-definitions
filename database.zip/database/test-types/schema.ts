import { relations } from 'drizzle-orm';
import {
    boolean,
    index,
    int,
    json,
    mysqlTable,
    varchar,
} from 'drizzle-orm/mysql-core';

// ─── Tables ──────────────────────────────────────────────────────────────────

export const testType = mysqlTable(
    'test_type',
    {
        id: varchar('id', { length: 10 }).primaryKey(),
        parentId: varchar('parent_id', { length: 10 }),
        sortId: varchar('sort_id', { length: 10 }),
        name: varchar('name', { length: 200 }).notNull(),
        testTypeName: varchar('test_type_name', { length: 200 }),
        typeOfTest: varchar('type_of_test', { length: 50 }),
        testTypeClassification: varchar('test_type_classification', { length: 50 }),
        suggestedTestTypeDisplayName: varchar('suggested_test_type_display_name', { length: 200 }),
        suggestedTestTypeDisplayOrder: varchar('suggested_test_type_display_order', { length: 10 }),
        forVehicleType: json('for_vehicle_type').$type<string[]>(),
        forVehicleSize: json('for_vehicle_size').$type<string[] | null>(),
        forVehicleConfiguration: json('for_vehicle_configuration').$type<string[] | null>(),
        forVehicleAxles: json('for_vehicle_axles').$type<number[] | null>(),
        forEuVehicleCategory: json('for_eu_vehicle_category').$type<string[] | null>(),
        forVehicleClass: json('for_vehicle_class').$type<string[] | null>(),
        forVehicleSubclass: json('for_vehicle_subclass').$type<string[] | null>(),
        forVehicleWheels: json('for_vehicle_wheels').$type<number[] | null>(),
        forProvisionalStatus: boolean('for_provisional_status'),
        forProvisionalStatusOnly: boolean('for_provisional_status_only'),
    },
    (table) => [
        index('idx_test_type_parent_id').on(table.parentId),
    ],
);

export const testCode = mysqlTable(
    'test_code',
    {
        id: int('id', { unsigned: true }).autoincrement().primaryKey(),
        testTypeId: varchar('test_type_id', { length: 10 }).notNull(),
        defaultTestCode: varchar('default_test_code', { length: 10 }).notNull(),
        linkedTestCode: varchar('linked_test_code', { length: 10 }),
        forVehicleType: varchar('for_vehicle_type', { length: 20 }),
        forVehicleSize: varchar('for_vehicle_size', { length: 20 }),
        forVehicleConfiguration: json('for_vehicle_configuration').$type<string[] | null>(),
        forVehicleAxles: json('for_vehicle_axles').$type<number[] | null>(),
        forEuVehicleCategory: json('for_eu_vehicle_category').$type<string[] | null>(),
        forVehicleClass: varchar('for_vehicle_class', { length: 10 }),
        forVehicleSubclass: json('for_vehicle_subclass').$type<string[] | null>(),
        forVehicleWheels: json('for_vehicle_wheels').$type<number[] | null>(),
        forProvisionalStatus: boolean('for_provisional_status'),
        forProvisionalStatusOnly: boolean('for_provisional_status_only'),
    },
    (table) => [
        index('idx_test_code_test_type_id').on(table.testTypeId),
    ],
);

export const testTypeRelationship = mysqlTable(
    'test_type_relationship',
    {
        id: int('id', { unsigned: true }).autoincrement().primaryKey(),
        testTypeId: varchar('test_type_id', { length: 10 }).notNull(),
        relatedTestTypeId: varchar('related_test_type_id', { length: 10 }).notNull(),
        relationshipType: varchar('relationship_type', { length: 10 }).notNull(),
    },
    (table) => [
        index('idx_ttr_test_type_id').on(table.testTypeId),
        index('idx_ttr_related_test_type_id').on(table.relatedTestTypeId),
    ],
);

// ─── Relations ───────────────────────────────────────────────────────────────

export const testTypeRelations = relations(testType, ({ one, many }) => ({
    parent: one(testType, {
        fields: [testType.parentId],
        references: [testType.id],
        relationName: 'parentChild',
    }),
    children: many(testType, { relationName: 'parentChild' }),
    testCodes: many(testCode),
    relationships: many(testTypeRelationship, { relationName: 'source' }),
    relatedBy: many(testTypeRelationship, { relationName: 'target' }),
}));

export const testCodeRelations = relations(testCode, ({ one }) => ({
    testType: one(testType, {
        fields: [testCode.testTypeId],
        references: [testType.id],
    }),
}));

export const testTypeRelationshipRelations = relations(testTypeRelationship, ({ one }) => ({
    testType: one(testType, {
        fields: [testTypeRelationship.testTypeId],
        references: [testType.id],
        relationName: 'source',
    }),
    relatedTestType: one(testType, {
        fields: [testTypeRelationship.relatedTestTypeId],
        references: [testType.id],
        relationName: 'target',
    }),
}));
