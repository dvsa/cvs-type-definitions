import { relations } from 'drizzle-orm';
import {
    bigint,
    boolean,
    index,
    int,
    json,
    mysqlTable,
    uniqueIndex,
    varchar,
} from 'drizzle-orm/mysql-core';

// ─── Tables ──────────────────────────────────────────────────────────────────

export const defectCategory = mysqlTable(
    'defect_category',
    {
        id: bigint('id', { mode: 'number', unsigned: true }).autoincrement().primaryKey(),
        imNumber: int('im_number', { unsigned: true }).notNull(),
        imDescription: varchar('im_description', { length: 500 }).notNull(),
        forVehicleType: json('for_vehicle_type').$type<string[]>(),
        additionalInfo: json('additional_info').$type<Record<string, { location: Record<string, string[] | number[] | null>; notes: boolean }>>(),
    },
    (table) => [
        uniqueIndex('idx_im_number_uq').on(table.imNumber),
    ],
);

export const defectItem = mysqlTable(
    'defect_item',
    {
        id: bigint('id', { mode: 'number', unsigned: true }).autoincrement().primaryKey(),
        defectCategoryId: bigint('defect_category_id', { mode: 'number', unsigned: true }).notNull(),
        itemNumber: int('item_number', { unsigned: true }).notNull(),
        itemDescription: varchar('item_description', { length: 500 }).notNull(),
        forVehicleType: json('for_vehicle_type').$type<string[]>(),
    },
    (table) => [
        index('idx_defect_item_category_id').on(table.defectCategoryId),
    ],
);

export const defectDeficiency = mysqlTable(
    'defect_deficiency',
    {
        id: bigint('id', { mode: 'number', unsigned: true }).autoincrement().primaryKey(),
        defectItemId: bigint('defect_item_id', { mode: 'number', unsigned: true }).notNull(),
        ref: varchar('ref', { length: 20 }).notNull(),
        deficiencyId: varchar('deficiency_id', { length: 10 }),
        deficiencySubId: varchar('deficiency_sub_id', { length: 10 }),
        deficiencyCategory: varchar('deficiency_category', { length: 20 }).notNull(),
        deficiencyText: varchar('deficiency_text', { length: 500 }),
        stdForProhibition: boolean('std_for_prohibition').notNull(),
        forVehicleType: json('for_vehicle_type').$type<string[]>(),
    },
    (table) => [
        index('idx_defect_deficiency_item_id').on(table.defectItemId),
        index('idx_defect_deficiency_ref').on(table.ref),
    ],
);

export const requiredStandardSection = mysqlTable(
    'required_standard_section',
    {
        id: bigint('id', { mode: 'number', unsigned: true }).autoincrement().primaryKey(),
        sectionNumber: varchar('section_number', { length: 20 }).notNull(),
        sectionDescription: varchar('section_description', { length: 500 }).notNull(),
        euVehicleCategories: json('eu_vehicle_categories').$type<string[]>().notNull(),
    },
    (table) => [
        index('idx_req_std_section_number').on(table.sectionNumber),
    ],
);

export const requiredStandard = mysqlTable(
    'required_standard',
    {
        id: bigint('id', { mode: 'number', unsigned: true }).autoincrement().primaryKey(),
        requiredStandardSectionId: bigint('required_standard_section_id', { mode: 'number', unsigned: true }).notNull(),
        rsNumber: int('rs_number', { unsigned: true }).notNull(),
        requiredStandard: varchar('required_standard', { length: 500 }).notNull(),
        refCalculation: varchar('ref_calculation', { length: 100 }).notNull(),
        additionalInfo: boolean('additional_info').notNull(),
        inspectionTypes: json('inspection_types').$type<string[]>().notNull(),
    },
    (table) => [
        index('idx_req_std_section_id').on(table.requiredStandardSectionId),
    ],
);

// ─── Relations ───────────────────────────────────────────────────────────────

export const defectCategoryRelations = relations(defectCategory, ({ many }) => ({
    items: many(defectItem),
}));

export const defectItemRelations = relations(defectItem, ({ one, many }) => ({
    category: one(defectCategory, {
        fields: [defectItem.defectCategoryId],
        references: [defectCategory.id],
    }),
    deficiencies: many(defectDeficiency),
}));

export const defectDeficiencyRelations = relations(defectDeficiency, ({ one }) => ({
    item: one(defectItem, {
        fields: [defectDeficiency.defectItemId],
        references: [defectItem.id],
    }),
}));

export const requiredStandardSectionRelations = relations(requiredStandardSection, ({ many }) => ({
    standards: many(requiredStandard),
}));

export const requiredStandardRelations = relations(requiredStandard, ({ one }) => ({
    section: one(requiredStandardSection, {
        fields: [requiredStandard.requiredStandardSectionId],
        references: [requiredStandardSection.id],
    }),
}));
