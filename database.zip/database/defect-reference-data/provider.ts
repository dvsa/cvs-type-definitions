import { Logger } from '@aws-lambda-powertools/logger';
import { FEAT_FLAGS, LOGGER } from '@domain/di-tokens/Tokens';
import { Timed } from '@dvsa/appdev-api-common/http/decorators';
import type { DefectDetailsSchema } from '@dvsa/cvs-type-definitions/types/v1/defect-details';
import type { MySql2Database } from 'drizzle-orm/mysql2';
import { NotFoundError } from 'routing-controllers';
import { Container, Inject, Service } from 'typedi';
import * as schema from './schema';

type DefectDb = MySql2Database<typeof schema>;

@Service()
export class DefectProvider {
    private readonly logger: Logger = Container.get(LOGGER);

    constructor(@Inject('DB') private readonly db: DefectDb) {}

    @Timed()
    async findAll(): Promise<DefectDetailsSchema[]> {
        const categories = await this.db.query.defectCategory.findMany({
            with: {
                items: {
                    with: {
                        deficiencies: true,
                    },
                },
            },
        });

        if (!categories.length) {
            throw new NotFoundError('No defects found');
        }

        const data = this.flatten(categories);

        const flags = Container.get(FEAT_FLAGS);

        if (flags.specialistDefects?.enabled) {
            return data;
        }

        const adasImNumbersSet = new Set(flags.specialistDefects?.adasImNumbers ?? []);

        this.logger.debug('ADAS IM Numbers to filter out:', { adasImNumbers: Array.from(adasImNumbersSet) });

        return data.filter((defect) => !adasImNumbersSet.has(defect.imNumber));
    }

    private flatten(
        categories: Awaited<ReturnType<DefectDb['query']['defectCategory']['findMany']>>,
    ): DefectDetailsSchema[] {
        const result: DefectDetailsSchema[] = [];

        for (const category of categories) {
            const additionalInfo = category.additionalInfo ?? {};

            for (const item of category.items) {
                for (const deficiency of item.deficiencies) {
                    result.push({
                        imNumber: category.imNumber,
                        imDescription: category.imDescription,
                        itemNumber: item.itemNumber,
                        itemDescription: item.itemDescription,
                        deficiencyRef: deficiency.ref,
                        deficiencyId: deficiency.deficiencyId ?? null,
                        deficiencySubId: deficiency.deficiencySubId ?? null,
                        deficiencyCategory: deficiency.deficiencyCategory,
                        deficiencyText: deficiency.deficiencyText ?? null,
                        stdForProhibition: deficiency.stdForProhibition,
                        prs: null,
                        prohibitionIssued: null,
                        additionalInformation: {
                            location: {
                                vertical: null,
                                horizontal: null,
                                lateral: null,
                                longitudinal: null,
                                rowNumber: null,
                                seatNumber: null,
                                axleNumber: null,
                            },
                            notes: '',
                        },
                        metadata: {
                            category: {
                                additionalInfo: additionalInfo as DefectDetailsSchema['metadata']['category']['additionalInfo'],
                            },
                        },
                    });
                }
            }
        }

        return result.sort((a, b) => a.imNumber - b.imNumber);
    }
}
